import requests
import csv

api_key = '2dc46126732b7d0ee4958b2817c1ef8f'
base_url = 'https://api.themoviedb.org/3'
genres_endpoint = '/genre/movie/list'
genres_params = {'api_key': api_key}
genres_response = requests.get(base_url + genres_endpoint, params=genres_params)
genres_data = genres_response.json()

# Create a dictionary to map genre IDs to genre names
genre_mapping = {genre['id']: genre['name'] for genre in genres_data.get('genres', [])}

# Step 2: Fetch popular movies with pagination
total_pages = 100  # Set the number of pages you want to retrieve
movies_endpoint = '/movie/popular'

# Accumulate all movie data
all_movies = []

for page in range(1, total_pages + 1):
    movies_params = {'api_key': api_key, 'page': page}
    movies_response = requests.get(base_url + movies_endpoint, params=movies_params)
    movies_data = movies_response.json()

    # Extract relevant information from the response
    movies = movies_data.get('results', [])
    all_movies.extend(movies)

# Define CSV file path
csv_file_path = 'all_movies.csv'

# Write all data to CSV
with open(csv_file_path, 'w', newline='', encoding='utf-8') as csvfile:
    fieldnames = ['id', 'title', 'release_date', 'overview', 'vote_average', 'genre_names', 'poster_url']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    # Write headers
    writer.writeheader()

    for movie in all_movies:
        genre_ids = movie.get('genre_ids', [])
        genre_names = [genre_mapping.get(genre_id, '') for genre_id in genre_ids]

        # Fetch poster URL for the movie
        poster_path = movie.get('poster_path', '')
        poster_url = f'https://image.tmdb.org/t/p/w500/{poster_path}' if poster_path else ''

        writer.writerow({
            'id': movie.get('id', ''),
            'title': movie.get('title', ''),
            'release_date': movie.get('release_date', ''),
            'overview': movie.get('overview', ''),
            'vote_average': movie.get('vote_average', ''),
            'genre_names': ', '.join(genre_names),
            'poster_url': poster_url
        })

print(f'All movies data with genres and images has been saved to {csv_file_path}')
