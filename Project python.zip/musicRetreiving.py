import requests
import base64
import csv
client_id = '3f54da7084d94089b94a047f32de866a'
client_secret = '2c7659cebdbc4bf7be67d679adc9ffa2'
credentials = base64.b64encode(f"{client_id}:{client_secret}".encode('utf-8')).decode('utf-8')
headers = {'Authorization': f'Basic {credentials}'}
token_url = 'https://accounts.spotify.com/api/token'

data = {'grant_type': 'client_credentials'}
response = requests.post(token_url, data=data, headers=headers)
access_token = response.json()['access_token']

headers = {'Authorization': f'Bearer {access_token}'}
genres = ['pop', 'rock', 'hip-hop']
tracks_data = []
for genre in genres:
    search_url = f'https://api.spotify.com/v1/search?q=genre:{genre}&type=track&limit=50'
    response = requests.get(search_url, headers=headers)
    track_info = response.json()
    if 'tracks' in track_info and 'items' in track_info['tracks']:
        for track in track_info['tracks']['items']:
            track_data = {
                'Genre': genre,
                'Track Name': track['name'],
                'Artist': track['artists'][0]['name'],
                'Preview URL': track['preview_url']
            }
            tracks_data.append(track_data)
    while track_info['tracks']['next']:
        next_url = track_info['tracks']['next']
        response = requests.get(next_url, headers=headers)
        track_info = response.json()
        if 'tracks' in track_info and 'items' in track_info['tracks']:
            for track in track_info['tracks']['items']:
                track_data = {
                    'Genre': genre,
                    'Track Name': track['name'],
                    'Artist': track['artists'][0]['name'],
                    'Preview URL': track['preview_url']
                }
                tracks_data.append(track_data)
csv_file = 'spotify_tracks_large_dataset.csv'
with open(csv_file, 'w', newline='', encoding='utf-8') as csvfile:
    fieldnames = ['Genre', 'Track Name', 'Artist', 'Preview URL']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(tracks_data)
print(f'Data has been saved to {csv_file}.')
